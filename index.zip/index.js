let name =prompt("what is your name");
document.write(name)